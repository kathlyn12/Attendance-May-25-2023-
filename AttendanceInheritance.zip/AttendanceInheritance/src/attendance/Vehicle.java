package attendance;

public class Vehicle {

	double speed = 160;
	String color = "Black";
	int price = 600000;
	
	void stop() {
		System.out.println("Stop the car!");
	}
}
